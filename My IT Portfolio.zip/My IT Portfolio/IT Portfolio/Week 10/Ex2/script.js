var name = prompt("Enter your Name: ");
var id = prompt("Enter your studentid: ");

alert(id + "\n" + name);